var MenuAlignment = {
  Left: 1,
  Right: 0,
  Center: 0.5,
}